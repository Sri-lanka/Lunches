package com.sena.lunches.repository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface user_sena_repo extends JpaRepository {

}
