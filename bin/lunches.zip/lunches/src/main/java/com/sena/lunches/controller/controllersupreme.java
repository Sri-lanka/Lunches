package com.sena.lunches.controller;

import com.sena.lunches.entities.user_sena;
import com.sena.lunches.repository.user_sena_repo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import java.util.List;


@Controller
@RequestMapping({"/","/inicio"})
public class controllersupreme {

    @Autowired
    private user_sena_repo userRepository;

    @GetMapping
    public String listarUsuarios(Model model) {
        List<user_sena> users = userRepository.findAll();
        model.addAttribute("usuarios", users);
        return "admin/principal/lista-usuarios";
    }

}
