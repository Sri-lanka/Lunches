package com.sena.lunches.entities;

public class user_sena {
    public class User_sena {
        private int Id_user;
        private int document;
        private int document_Type;
        private int rol;
        private String Name1;
        private String Name2;
        private String Lastname1;
        private String Lastname2;
        private int Age;
        private String Email;
        private int phone;
        private int status;
        private int id_benefit;


        //constructores
        public User_sena() {
        }
        public User_sena(int Id_user, int document, int document_Type, int rol, String Name1, String Name2, String Lastname1, String Lastname2, int Age, String Email, int phone, int estado, int id_benefit) {
            this.Id_user = Id_user;
            this.document = document;
            this.document_Type = document_Type;
            this.rol = rol;
            this.Name1 = Name1;
            this.Name2 = Name2;
            this.Lastname1 = Lastname1;
            this.Lastname2 = Lastname2;
            this.Age = Age;
            this.Email = Email;
            this.phone = phone;
            this.status = estado;
            this.id_benefit = id_benefit;
        }

//getters y setters

        public int getId_user() {
            return Id_user;
        }

        public void setId_user(int Id_user) {
            this.Id_user = Id_user;
        }

        public int getDocument() {
            return document;
        }

        public void setDocument(int document) {
            this.document = document;
        }

        public int getDocument_Type() {
            return document_Type;
        }

        public void setDocument_Type(int document_Type) {
            this.document_Type = document_Type;
        }

        public int getRol() {
            return rol;
        }

        public void setRol(int rol) {
            this.rol = rol;
        }

        public String getName1() {
            return Name1;
        }

        public void setName1(String Name1) {
            this.Name1 = Name1;
        }

        public String getName2() {
            return Name2;
        }

        public void setName2(String Name2) {
            this.Name2 = Name2;
        }

        public String getLastname1() {
            return Lastname1;
        }

        public void setLastname1(String Lastname1) {
            this.Lastname1 = Lastname1;
        }

        public String getLastname2() {
            return Lastname2;
        }

        public void setLastname2(String Lastname2) {
            this.Lastname2 = Lastname2;
        }

        public int getAge() {
            return Age;
        }

        public void setAge(int Age) {
            this.Age = Age;
        }

        public String getEmail() {
            return Email;
        }

        public void setEmail(String Email) {
            this.Email = Email;
        }

        public int getPhone() {
            return phone;
        }

        public void setPhone(int phone) {
            this.phone = phone;
        }

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public int getId_benefit() {
            return id_benefit;
        }

        public void setId_benefit(int id_benefit) {
            this.id_benefit = id_benefit;
        }



    }
}
