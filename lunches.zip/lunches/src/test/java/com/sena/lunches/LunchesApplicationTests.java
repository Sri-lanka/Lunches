package com.sena.lunches;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LunchesApplicationTests {

	@Test
	void contextLoads() {
	}

}
