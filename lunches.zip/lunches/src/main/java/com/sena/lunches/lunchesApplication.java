package com.sena.lunches;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class lunchesApplication {

	public static void main(String[] args) {
		SpringApplication.run(lunchesApplication.class, args);
	}

}
