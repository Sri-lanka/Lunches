package com.sena.lunches.service.impl;

import com.sena.lunches.entities.User_sena;
import com.sena.lunches.repository.User_sena_repo;
import com.sena.lunches.service.User_sena_service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Locale;

@Service
public class UserImpl implements User_sena_service {

    @Autowired
    private User_sena_repo userDataRepository;

    @Override
    public List<User_sena> getUserSena() {
        return User_sena_repo.findAll();
    }

    @Override
    public User_sena saveUserSena(User_sena userData) {
        return userDataRepository.save(userData);
    }

    @Override
    public User_sena getUserSenaById(Long id) {
        return userDataRepository.findById(id).orElse(null);
    }

    @Override
    public UserData updateUserData(Long id, UserData userData) {
        UserData oldUserData = userDataRepository.findById(id).orElse(null);

        if (oldUserData != null){
            oldUserData.setDocument(userData.getDocument());
            oldUserData.setAge(userData.getAge());
            oldUserData.setNameUser(userData.getNameUser());
            oldUserData.setEmail(userData.getEmail());
            oldUserData.setPhone(userData.getPhone());
            oldUserData.setRoleUser(userData.getRoleUser());
            oldUserData.setPassword(userData.getPassword());
            oldUserData.setProfilePicture(userData.getProfilePicture());
            return userDataRepository.save(oldUserData);
        }
        return null;
    }

    @Override
    public void deleteUserData(Long id) {
        userDataRepository.deleteById(id);
    }

    @Override
    public UserData loginUser(String document, String password) {
        UserData user = userDataRepository.findByDocumentAndPassword(document, password);

        if (user != null && user.getRoleUser().equals("admin")){
            return user;
        }
        return null;
    }
}
