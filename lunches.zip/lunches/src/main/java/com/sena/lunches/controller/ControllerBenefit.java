package com.sena.lunches.controller;


import com.sena.lunches.entities.Benefit;
import com.sena.lunches.repository.Benefit_repo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@Controller
@RequestMapping("/benefit")
public class ControllerBenefit {
    @Autowired
    private Benefit_repo benefitRepo;
    @GetMapping("/listBenefit")
    public String listBenefit(Model model) {
        try {
            List<Benefit> benefits = benefitRepo.findAll();
            model.addAttribute("benefit", benefits);
        }catch (Exception e) {
            System.out.println("Error: " + e);
        }
        return "admin/principal/list-users";
    }

}
