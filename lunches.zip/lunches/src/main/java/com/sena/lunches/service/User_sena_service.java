package com.sena.lunches.service;

import java.util.List;
import com.sena.lunches.entities.User_sena;
public interface User_sena_service {

    public List<User_sena> getUserSena();

    public  User_sena saveUserSena(User_sena userSena) ;

    public User_sena getUserSenaById(int id);


    public User_sena updateUserData(Long id, User_sena userSena);

    public void deleteUserData(int id);


}
